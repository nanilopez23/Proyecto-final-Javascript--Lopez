
// 03 crear un algoritmo usando un ciclo

let number1 = parseInt(prompt("Ingrese un numero menor a 5 que sera sumado en cada iteración"))
let suma = 0
for (let i=0; i < 3; i++){
    let number2 = parseInt(prompt ("Ingrese el número para sumar"))
    suma = number1 + number2
    console.log (suma)
}


let usuario = prompt ("Ingrese su nombre")

for (usuario; usuario !== "Juan Ignacio";) {

    alert("Nombre incorrecto, pruebe nuevamente")
    usuario = prompt("Ingrese nuevamente")
}
alert("Bienvenido Juan Ignacio")

let cantidad = parseInt(prompt("Ingrese un número para repetir el mensaje",0))
for (let i = 1; i <= cantidad; i++){
    alert("Martin Tutor")
}

let texto = prompt( "Ingrese una frase");
let resultado = texto ;
let texto2 = " ";

while (texto2 != "ESC"){
    texto2 = prompt("ingrese una frase para unir a la anterior")
    resultado = resultado + " " + texto2 
    console.log (resultado)
}




